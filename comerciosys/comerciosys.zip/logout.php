<?php
/**
 * Página de logout del sistema
 * ComercioSys - Sistema de Gestión de Ventas
 */

require_once 'includes/auth.php';

// Cerrar sesión y redirigir
logout();
?>
